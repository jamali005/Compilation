#include "analys.h"
#include "tablesymb.h"
#include "cfg.h"
#include "error.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int yylex();

typetoken token;
boolean follow_token;


varvalueType varattribute;
typevalueType typeattribute;
tokenvalueType tokenattribute;
constvalueType constattribute;
stringvalueType stringattribute;




int rangvar;
boolean semanticerror = false;



typetoken _lire_token(){
	if (follow_token){
		follow_token = false;
		return token;
	}
	else{
		return (typetoken) yylex();
	}
}





int main(int argc , char** argv ){

	token = _lire_token();
	
	
	if (_prog() == true){
		
		printf(" successful operation\n");
		
	}
	else {
		
		printf(" operation failed\n");
	}
	
	
	/*
	if (_decl()==true){
		printf("successful operation\n");
	}
	else {
		printf("operation failed\n");
	}
	*/
	
}



//TYPE = INTEGER|STRING|FLOAT|CHAR|BOOL|NATURAL|POSITIVE|IDF|CONSTANT

boolean _type(){
	
	boolean result;
	
	if (token == IDF){
		typeattribute.typename = Identificateur;
		result = true;
	}
	
	else if (token == INTEGER){
		typeattribute.typename = Integer;
		result = true;
	}
	
	else if (token == STRING){
		typeattribute.typename = String;
		result = true;
	}
	
	else if (token == FLOAT){
		typeattribute.typename = Float;
		result = true;
	}
	
	else if (token == CHAR){
		typeattribute.typename = Char;
		result = true;
	}
	
	else if (token == BOOL){
		typeattribute.typename = Bool;
		result = true;
	}
	
	else if (token == NATURAL){
		typeattribute.typename = Natural;
		result = true;
	}
	
	else if (token == POSITIVE){
		typeattribute.typename = Positive;
		result = true;
	}
	
	else if (token == CONSTANT){
		typeattribute.typename = Constant;
		result = true;
	}
	else {
		creer_sx_erreur(TypeExpected, tokenattribute.line);
		result = false;
	}
	
	return result;
	
}

//CONST = DNUMBER|INUMBER|TRUE|FALSE 

boolean _const(){
	
	boolean result;
	
	if(token == DNUMBER){
		constattribute.typename = Double;
		result=true;
	}
	
	else if(token == INUMBER){
		constattribute.typename = Integer;
		result=true;
	}
	
	else if(token == TRUE){
		constattribute.typename = Bool;
		result=true;
	}
	
	else if(token == FALSE){
		constattribute.typename = Bool;
		result=true;
	}
	
	else {
		creer_sx_erreur(ConstExpected, tokenattribute.line);
		result = false;
	}
	
	return result;
	
}
//CONSTAUX = CONST|ARRAY
boolean _constaux(){
	
	boolean result;
	if(_const()){
		result=true;
	}
	else if(_array()){
		result=true;
	}
	else{
		creer_sx_erreur(ConstExpected, tokenattribute.line);
		result=false;
	}
	return result;
}
//DECL_AUX = := CONSTAUX PVIRG | PVIRG
//CONSTAUX = CONST|ARRAY
boolean _decl_aux(){
	boolean result;
	
	if (token == AFFECTATION){
		printf(" affectation(:=) detected \n");
		token = _lire_token();
		
		if (_constaux()==true){
			printf(" const detected\n");
			token = _lire_token();
			if(token == PVIRG){
				varattribute.initialisation = true;
				result = true;
			}
			else{
				creer_sx_erreur(PvirgExpected, tokenattribute.line);
				printf("error ;");
				result = false;
			}
		}
		else {
			printf(" const NOT detected\n");
			result = false;
			}
	
	}
	else if (token==PVIRG){
		varattribute.initialisation = false;	
		printf(" fin_PVIRG detected\n");
		result = true;
	}
	else{
		creer_sx_erreur(PvirgExpected, tokenattribute.line);
		printf(" erreur_decl_aux detected\n");
		result = false;
	}
	
	return result;
}



//DECL = IDF : TYPE DECL_AUX|

boolean _decl(){
	
	boolean result = false ;
	
	if (token == IDF){
		printf(" IDF detected \n");
		token = _lire_token();
		
		if (token == GTYPE){
			printf(" GTYPE(:) detected \n");
			token = _lire_token();
			
			if (_type() == true){
				printf(" type detected \n");
				token = _lire_token();
				
				if (_decl_aux() == true){
					
					if (inTS(varattribute.name, &rangvar) == true) {
						printf(" variable already declared \n");
						semanticerror = true;
						creer_sm_erreur(AlreadyDeclared, varattribute.line, varattribute.name);
					}
					else{
						printf(" nouvelle variable \n");
						varvalueType newvar;
						newvar.nbdecl = 1;
						newvar.name = (char *)malloc(sizeof(char)*strlen(varattribute.name)+1);
						strcpy(newvar.name, varattribute.name);
						if (debug) printf("VAR{%s}-->NEW{%s}",varattribute.name, newvar.name);
						newvar.line = varattribute.line;
						newvar.initialisation = varattribute.initialisation; // l'initialisation est marquée par decl_aux dans varattribute
						newvar.utilisation = false; //toute variable est par défaut non utilisee
						newvar.typevar = typeattribute.typename;
						switch(newvar.typevar){
							//printf(" dans le switch \n");
							case String : setsvalue(&(newvar.valinit) , ((varattribute.initialisation == true)?stringattribute.value:"")); break;
							case Double : setdvalue(&(newvar.valinit) , ((varattribute.initialisation == true)?constattribute.valinit:0.0)); break;
							case Integer : setdvalue(&(newvar.valinit) , ((varattribute.initialisation == true)?constattribute.valinit:0)); break;
							// a completer
							default : setdvalue(&(newvar.valinit) , ((varattribute.initialisation == true)?constattribute.valinit:0.0)); break;
						}
						ajouter_nouvelle_variable_a_TS(newvar);
					}
					
					// 6eme gestion erreur BadlyInitialised : l'IDF peut avoir été initialisé par une constante du mauvais type
					if (varattribute.initialisation == true){
						printf("analyse the constant /n");
						if (constattribute.typename != typeattribute.typename){ //Int/Double|String, Double/Int|String, Double/Bool|String, Bool/Double|String, Int/Bool|String, Bool/Int|String, //String|Int/Double, String/Double|Int, String/Double|Bool, String/Bool|Double, String/Int|Bool, String/Bool|Int,
							if ( (typeattribute.typename != Float) || (constattribute.typename != Integer) ){  // ce n'est pas Double := Integer
								semanticerror = true;
								creer_sm_erreur(BadlyInitialised, varattribute.line, varattribute.name);
							}
							//sinon (i.e Double := Int) alors il y a un casting implicit Double = (Double) Int ;-)
							else if ( (typeattribute.typename != Bool) || (constattribute.typename != Integer) ){  // ce n'est pas Bool := Integer
								semanticerror = true;
								creer_sm_erreur(BadlyInitialised, varattribute.line, varattribute.name);
							}
							
							else if ( (typeattribute.typename != Integer) || (constattribute.typename != Bool) ){  // ce n'est pas Integer := bool
								semanticerror = true;
								creer_sm_erreur(BadlyInitialised, varattribute.line, varattribute.name);
							}
							else if ( (typeattribute.typename != Float) || (constattribute.typename != Bool) ){  // ce n'est pas Double := bool
								semanticerror = true;
								creer_sm_erreur(BadlyInitialised, varattribute.line, varattribute.name);
							}
							else if ( (typeattribute.typename != Bool) || (constattribute.typename != Double) ){  // ce n'est pas Bool := Double
								semanticerror = true;
								creer_sm_erreur(BadlyInitialised, varattribute.line, varattribute.name);
							}
							
							// a completer
						}
					}
					printf(" result = true \n");
					result = true;


				}
				
			}else {printf(" type NOT detected \n");}
				
		}else {printf(" GTYPE(:) NOT detected \n");}
		
	}else {
		printf(" IDF NOT detected \n");
		creer_sx_erreur(IdfExpected, tokenattribute.line);
	}
		
	return result;	
	
}

// LISTE_DECL = DECL LISTE_DECL_AUX 

boolean _liste_decl(){
	boolean result;
	if (_decl()){
		printf("___________________________________\n");
		token = _lire_token();
		if (_liste_decl_aux()){
			result = true;
		}
		else {
			result = false;
		}
	}
	else {
		result = false;
	}
	
	return result;
}


//LISTE_DECL_AUX = LISTE_DECL | EPS
boolean _liste_decl_aux(){
	boolean result;
	
	if (token==BEG_IN){
		follow_token = true;
		result = true;
	}
	else if (_liste_decl()){
		result = true;
	}
	else {
		result = false;
	}
	
	return result;
	
}


/*
boolean _prog(){
	boolean result;
	
	if (_liste_decl()){
		token = _lire_token();
		if (token == BEG_IN){
			result = true;
		}
		else {
			result = false;
		}
	}
	else {
		result = false;
	}
	
	return result;
}

*/
//PROG : LISTE_DECL begin LISTE_INST end
boolean _prog(){
	boolean result;
	
	if (_liste_decl()){
		token = _lire_token();
		if (token == BEG_IN){
			printf(" BEGIN detected \n");
			token = _lire_token();
			if (_liste_inst()){
				token = _lire_token();
				if (token == END){
					printf(" END detected \n");
					token = _lire_token();
					if (token == PVIRG){
						printf(" fin_inst detected \n");
						result = true;
					}
					else {result = false;}
				}
				else {
					creer_sx_erreur(EndExpected, tokenattribute.line);
					result = false;
				}
			}
			else {result = false;}
		}
		else {
			creer_sx_erreur(BeginExpected, tokenattribute.line);
			result = false;
		}
	}
	else {
		result = false;
	}
	
	return result;
}


//ARRAY_LIST: (LISTNUM)
//LISTNUM : NUM ListNUM_aux
//List_num_aux : virg num|eps


boolean _array(){
	boolean result;
	
	if(token == POPEN){
		token=_lire_token();
		if(_listenum()){
			token=_lire_token();			
			if(token == PCLOSE){
				result = true ;
			}
			else{
				printf("error pclose\n");
				result = false;
			}
		}
		else{
			printf("error _listenum\n");
			result = false;
		}
	}
	else{
		printf("error popen\n");
		result = false;
	}
	return result;
}
//LISTNUM : NUM ListNUM_aux
//List_num_aux : virg num listnumaux|eps
boolean _listenum(){
	boolean result;
	if((token == DNUMBER) || (token == INUMBER)){
		token = _lire_token();
		if(_listnum_aux()){
			result = true;
		}
		else{
			printf("error f l virg");
			result = false;
		}
	}
	else{
		printf("error f nmari");
		result = false;
	}
		
return result;
}
//List_num_aux : virg num listnumaux|eps
boolean _listnum_aux(){
	boolean result;
	if(token == VIRG){
		token = _lire_token();
		if((token == DNUMBER) || (token == INUMBER)){
			token = _lire_token();
			if(_listnum_aux()){
				
				result = true;
			}
			else{
				printf("erro hvcbsnxkr\n");
				result = false;
			}
		}
		else{
			printf("error f nemra li mor l virg");
			result = false;
		}
	}
	else if(token == PCLOSE){
		follow_token = true;
		result = true;
	}
	else{
		result = false;
	}
return result;
}


//  INSTR : for IDF inumber .. inumber loop LISTE_INST endLoop|put_line();
boolean _instr(){
	boolean detectTirets = true;
	boolean result=false;
	printf("dans instr");
	if (token == LOOPFOR){
		printf(" FOR detected \n");
		token = _lire_token();
		
		if (token == IDF){
			printf(" IDF detected \n");
			token = _lire_token();
			
			if (token == IN){
				printf(" in detected \n");
				token = _lire_token();
				
				if (token == INUMBER){
					printf(" INUMBER detected \n");
					token = _lire_token();
					
					if (token == BETWEEN){
						printf(" .. detected \n");
						token = _lire_token();
						
						if (token == INUMBER){
							printf(" INUMBER detected \n");
							token = _lire_token();
							
							if (token == LOOP){
								printf(" loop detected \n");
								token = _lire_token();
								
								if (_liste_inst()){
									token = _lire_token();
									
									if (token == END){
										printf(" END detected \n");
										token = _lire_token();
										
										if (token == LOOP){
											printf(" Loop detected \n");
											token = _lire_token();
											
											if (token == PVIRG){
												printf(" fin_inst detected \n");
												result = true;
											}
											else {
												result = false;
											}
										}
										else {
											result = false;
										}
									}
									else {
										result = false;
									}
								}
								else {
									result = false;
								}
							}
							else {
								result = false;
							}
						}
						else {
							result = false;
						}
					}
					else {
						result = false;
					}
				}
				else {
					result = false;
				}
			}
			else {
				result = false;
			}
		}
		else {
			result = false;
		}
	}
	else if (token == PUTLINE){
		printf(" Put_Line detected \n");
		token = _lire_token();
		if (token == POPEN){
			printf(" ( detected \n");
			token = _lire_token();
			printf("toto");
			if (token == TIRETS){    // detection des tirets
				printf(" tirets detected \n");
				token = _lire_token();
				while(token != TIRETS){  // boucle pour ecrire n'importe quoi sauf ; et " (je vais la régler bientot, car il faut faire /" sdaa3 rass....)
					token = _lire_token();
					if (token == PVIRG){
						detectTirets = false;
						printf(" inst(;) is detected before tirets \n");
						result = false;
						break; // arreter si on detecte ; avant ")
					}
				}
				if (detectTirets){ // condition pour savoir si on est sorti de while en detectant ; ou bien "
					token = _lire_token();
					if (token == PCLOSE){
						printf(" ) detected \n");
						token = _lire_token();
						if (token == PVIRG){
							printf(" fin_inst detected \n");
							result = true;
						}
						else {
							result = false;
						}
					}
					else {
						result = false;
					}
				}
			}
			printf("totoo");
			
		}
		else {
			result = false;
		}
	}
	
	else {
		result = false;
	}
	
	return result;
	
}	
/*	else if (token == PUTLINE){
		printf(" Put_Line detected \n");
		token = _lire_token();
		if (token == POPEN){
			printf(" ( detected \n");
			token = _lire_token();
			if (token == PCLOSE){
				printf(" ) detected \n");
				token = _lire_token();
				if (token == PVIRG){
					printf(" fin_inst detected \n");
					result = true;
				}
				else {
					result = false;
				}
			}
			else {
				result = false;
			}
		}
		else {
			result = false;
		}
	}
	
	else {
		result = false;
	}
	
	return result;
	
}*/
//OPER :
//COND :IDF = OPER
//(IF_STAT : if COND then LIST_INST IF_INSTAU) 
//INST : (IF_STAT)if COND then LIST_INST IF_INSTAU |AFFECTATION|PRINT
//LIST_INST : INST LIST_INSTAUX 
//LIST_INSTAUX : LIST_INST | EPS
//IFINSTAUX:END IF;|ELSE LIST_INST END IF ;

//boolean _condition();
//boolean _instement();
//boolean _else_instement();
//boolean _else_statement();
//boolean oper();
//boolean _inst();
//boolean if_insteaux();
//boolean inst();
//boolean _liste_inst();

//IFINSTAUX:END IF;|ELSE LIST_INST END IF ;
//COND :IDF = ADDSUB
boolean _condition(){
	boolean result ;
	token= _lire_token();
	if(token==IDF){
		//printf("hjkj111\n");
		token=_lire_token();
		if(token==EGAL){
			//token=_lire_token();
			if(_addsub()){
				printf("hjkj\n");
				result=true;
			}
		}
		else{
			printf("error Egal condition \n");
			result = false;
		}
	}
	else{
		printf("error IDF condition\n");
		result = false;
	}
	return result;
}

//AFFECTATION :IDF := ADDSUB
boolean _affectation(){
	boolean result ;
	//token= _lire_token();
	if(token==IDF){
		token=_lire_token();
			if(token == AFFECTATION){
				printf("salam\n");
				if(_addsub()){
					printf("ahlaan\n");
					result=true;
				}
				else{
					printf("error addsub affect\n");
					result=false;
				}
			}
			else{
				printf("error affe\n");
			}	
	}
	else{
		result = false;
		printf("error _affectation\n");
	}
	return result;
}
//MULTDIV : AUX MULTDIVAUX

boolean _multdiv(){
	boolean result = false;

	if(_aux()){
		printf("wach labas\n");
		if(_multdivaux()){
			result=true;
		}
		else{
			result = false;
			printf("error MULTDIVAUX");
		}
	}
	else{
		result = false;
		printf("error aux");
	}
	
	return result;
}


//MULTDIVAUX : * AUX MULTDIVAUX
//		| / AUX MULTDIVAUX
//		| epsilon
boolean _multdivaux(){
			boolean result = false;
			//token = _lire_token();
			if(token == MULT){
				if(_aux()){
					if(_multdivaux()){
						result = true;
					}
					else{
						result=false;
						printf("error MULTDIVAUX\n");
					}
				}
				else{
					result=false;
					printf("error AUX\n");
				}
			}
			else if(token == DIV){
				if(_aux()){
					if(_multdivaux()){
						result = true;
					}
					else{
						result=false;
						printf("error MULTDIVAUX\n");
					}
				}
				else{
					result=false;
					printf("error AUX\n");
				}

			}
			else if (token == THEN|token == ELSE
				){
				follow_token = true;
				result = true;
			}
			else{
				result = false;
			}


}


//ADDSUB : MULTDIV ADDSUBAUX
boolean _addsub(){
	boolean result;

	if(_multdiv()){
		printf("chooftchoof okan\n");
		if(_addsubaux()){
			result=true;
		}
		else{
		result = false;
		printf("error ADDSUBAUX");
		}
	}
	else{
		result = false;
		printf("error multdiv");
	}
return result;
}
//ADDSUBAUX : – MULTDIV ADDSUBAUX
//           | + MULTDIV ADDSUBAUX
//           | epsilon


boolean _addsubaux(){
	boolean result = false;
	token = _lire_token();
	if(token == MINUS){
		if(_multdiv()){
			if(_addsubaux()){
				result = true;
			}
			else{
				result=false;
				printf("error ADDSUBAUX\n");
			}
		}
		else{
			result=false;
			printf("error multdiv\n");
		}
	}
	else if(token == PLUS ){
		if(_multdiv()){
			if(_addsubaux()){
				result = true;
			}
			else{
				result=false;
				printf("error ADDSUBAUX\n");
			}
		}
		else{
			result=false;
			printf("error multdiv\n");
		}

	}
	else if (token == THEN | token == ELSE |token == END){
		follow_token = true;
		result = true;
	}
	else{
		result = false;
	}


}
//AUX : inumber | dnumber
//     | ( ADDSUB )

boolean _aux(){
	boolean result;
	token = _lire_token();
	if(token = IDF){
		result = true;
	}
	else if(token = INUMBER){
		result = true;
	}
	else if(token = DNUMBER){
		result = true;
	}
	else if(token == POPEN){
		token = _lire_token();
		if(_addsub()){
			token = _lire_token();
			if(token ==PCLOSE){
				result= true;
			}
		}
	}
	else{
		result = false;
	}
}
boolean _if_insteaux(){
	boolean result = false;
	if(token == END){
		token = _lire_token();
		if(token == IF){
			token = _lire_token();
			if(token == PVIRG){
				result = true;
			}
			else{
				printf("rak nssiti ;");
				result = false;
			}
		}
		else{
			printf("error if lool");
			result = false;
		}
	}
	else if(token == ELSE){
		token = _lire_token();
		if(_liste_inst()){
			token = _lire_token();
			if(token == END){
				token = _lire_token();
				if(token == IF){
					token = _lire_token();
					if(token == PVIRG){
						result = true;
					}
					else{
						printf("rak nssiti ;");
						result = false;
					}
				}
				else{
					printf("error if lilili");
					result = false;
				}
			}
		}
	}
return result;

}

//INST : if COND then LIST_INST IF_INSTAU|AFFECTATION|PRINT|for IDF inumber .. inumber loop LISTE_INST endLoop|put_line();
boolean _inst(){
	boolean result = false;
//	token = _lire_token();
	if (token == IF) {
		if (_condition()) {
			printf("cond");
			token = _lire_token();
			if (token == THEN) {
				printf("then");
				token = _lire_token();
				if (_liste_inst()) {
					printf("idf");
					token = _lire_token();
  					 if (_if_insteaux()) {
	    					result = true;
	    				}
	    				else{
	    					printf("error _if_insteaux()");
	    					result = false;
	    				}
	    			}
	    			else{
	    				printf("error _list_insteaux");
	    				result = false;
	    			}
	    		}
	    		else{
	    			printf("error THEN");
	    			result = false;
	    		}
	 	}
	    	else{
	    		printf(" error _condition");
	    		result = false;
	    	}
	}   
	//else if(_affectation()){
	//	result = true;
	//}
	//else if(_print()){
		//result = true;
	//}
	else if(_affectation()){
		result =true;	
	}
	else if(_instr()){
		result = true;
	}
return result;

}

//LIST_INST : INST LIST_INSTAUX 

boolean _liste_inst(){
	boolean result = false;
	if(_inst()){
	printf("- - - - - - - - - - - - - - - - - - - - - - - - \n");
		token = _lire_token();
		if(_liste_inst_aux()){
			result = true;
		}
		else{
			result = false;
		}
	}
	else{
		result =false;
	}
return result;
}

//LISTE_INSTAUX : LISTE_INST | epsilon
boolean _liste_inst_aux(){
	boolean result;
	
	if (token == END){
		
		follow_token = true;
		result = true;
	}
	else if (token == ELSE){
		follow_token = true;
		result = true;
	}
	
	else if (_liste_inst()){
		result = true;
	}
	
	else {
		result = false;
	}
	
	return result;
	
}



void set_idf_attributes(char *name, int line){
	if (debug) printf("[%s]", name);
	varattribute.name = (char *)malloc(sizeof(char) * strlen(name)+1);
	strcpy(varattribute.name, name);
	if (debug) printf("[%s]", varattribute.name);
	varattribute.line = line;
}

void set_number_attributes(double value){
	constattribute.valinit = value;
}




//#############################################REFAIRE########################
//LISTE_INST : INSTR LISTE_INSTAUX
/*boolean _liste_inst(){
	
	boolean result;
	
	if (_instr()){
		token = _lire_token();
		printf("- - - - - - - - - - - - - - - - - - - - - - - - \n");
		if (_liste_inst_aux()){
			result = true;
		}
		else {
			result = false;
		}
	}
	
	else {
		result = false;
	}
	
	return result;
}
*/
/*
//LISTE_INSTAUX : LISTE_INST | epsilon
boolean _liste_inst_aux(){
	
	boolean result;
	
	if (token == END){
		
		follow_token = true;
		result = true;
	}
	
	else if (_liste_inst()){
		result = true;
	}
	
	else {
		result = false;
	}
	
	return result;
	
}
*/








		



